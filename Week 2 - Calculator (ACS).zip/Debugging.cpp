/*
 * Calculator.cpp
 *
 *  Date: 03/08/2023
 *  Author: Andrea Carmen Sherry
 */

#include <iostream>

using namespace std;

int main() {

	char statement[100]; //Although it is declaring a character type variable, it is not necessary. 
	int op1, op2; //Necessary to store whole numbers.
	char operation;
	char answer; //Missing semicolon.
	do {
		cout << "Enter expression" << endl;
		cin >> op1 >> operation >> op2; //Change position of operation 1 and operation 2.
		//Declare each operation: +, -, *, /.
		//Begin declaring addition operation: 
		if (operation == '+') { //Change quotation mark for single quotation marks to identify and represent the single value and change semicolon for curly braces. 
			cout << op1 << " + " << op2 << " = " << op1 + op2 << endl; //Change the symbol next to cout (>>) for the right one which is <<. 
		}
		//Declare substraction operation:
		if (operation == '-') { //Use curly braces for each start of "if" declared in the code.
			cout << op1 << " - " << op2 << " = " << op1 - op2 << endl;
		} //Close curly braces. 
		//Declare multiplication operation:
		if (operation == '*') {
			cout << op1 << " * " << op2 << " = " << op1 * op2 << endl; //For each pair of operations, the right symbol should be used in between them. For this one I added * to declare multiplication. 
		}
		//Declare division operation: 
		if (operation == '/') {
			cout << op1 << " / " << op2 << " = " << op1 / op2 << endl; //Wrong symbol as it is declaring multiplication rather than division. Change "*" for "/" to declare division. 
		}
		cout << "Do you wish to evaluate another expression? " << endl;
		cin >> answer;
	} while (answer == 'Y' || answer == 'y');
	if (answer == 'N' || answer == 'n') {
		cout << "Program Finished";
	}
	return 0;
}
